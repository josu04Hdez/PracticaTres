/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tiendapracticatres;

import java.util.Random;
import javax.swing.JOptionPane;


public class Tienda {
    private String[] productos;
    private int[][] ventas;
    private final int DIAS = 7;

    public Tienda(int numProductos) {
        productos = new String[numProductos];
        ventas = new int[DIAS][numProductos];
        generarVentas();
    }

    
    public void ingresarProductos() {
        for (int i = 0; i < productos.length; i++) {
            productos[i] = JOptionPane.showInputDialog("Ingrese el nombre del producto " + (i + 1) + ":");
        }
    }
    
    // metodo para generar una venta random 
    
    private void generarVentas() {
        Random rand = new Random();
        for (int i = 0; i < DIAS; i++) {
            for (int j = 0; j < productos.length; j++) {
                ventas[i][j] = rand.nextInt(10);
            }
        }
    }

    //Metodo para calcular el total de ventas 
    
    public void calcularTotalVentas() {
        StringBuilder resultado = new StringBuilder("Total de ventas por producto:\n");
        for (int j = 0; j < productos.length; j++) {
            int total = 0;
            for (int i = 0; i < DIAS; i++) {
                total += ventas[i][j];
            }
            resultado.append(productos[j]).append(": ").append(total).append("\n");
        }
        JOptionPane.showMessageDialog(null, resultado.toString());
    }
    
    //metodo para calcular el dia de mayor venta
    
    public void calcularDiaMayorVenta() {
        String[] diasSemana = {"Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"};
        int maxVentas = 0, diaMayor = 0;
        for (int i = 0; i < DIAS; i++) {
            int totalDia = 0;
            for (int j = 0; j < productos.length; j++) {
                totalDia += ventas[i][j];
            }
            if (totalDia > maxVentas) {
                maxVentas = totalDia;
                diaMayor = i;
            }
        }
        JOptionPane.showMessageDialog(null, "El día con mayores ventas es " + diasSemana[diaMayor] + " con " + maxVentas + " ventas.");
    }

    // metodo para calcular el producto mas vendido 
    public void calcularProductoMasVendido() {
        int maxVentas = 0, productoMayor = 0;
        for (int j = 0; j < productos.length; j++) {
            int total = 0;
            for (int i = 0; i < DIAS; i++) {
                total += ventas[i][j];
            }
            if (total > maxVentas) {
                maxVentas = total;
                productoMayor = j;
            }
        }
        JOptionPane.showMessageDialog(null, "El producto más vendido es " + productos[productoMayor] + " con " + maxVentas + " unidades.");
    }
}


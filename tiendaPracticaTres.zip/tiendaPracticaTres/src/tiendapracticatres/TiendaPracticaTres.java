/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tiendapracticatres;

import javax.swing.JOptionPane;
import java.util.Random;

public class TiendaPracticaTres {

    public static void main(String[] args) {
        int numProductos = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el número de productos:"));
        Tienda tienda = new Tienda(numProductos);
        tienda.ingresarProductos();
        //menu principal 
        int opcion;
        do {
            opcion = Integer.parseInt(JOptionPane.showInputDialog(
                "Menú Principal:\n" +
                "1. Mostrar total de ventas por producto\n" +
                "2. Mostrar el día con mayores ventas\n" +
                "3. Mostrar el producto más vendido\n" +
                "4. Salir\n" +
                "Seleccione una opción:"));

            switch (opcion) {
                case 1:
                    tienda.calcularTotalVentas();
                    break;
                case 2:
                    tienda.calcularDiaMayorVenta();
                    break;
                case 3:
                    tienda.calcularProductoMasVendido();
                    break;
                case 4:
                    JOptionPane.showMessageDialog(null, "Saliendo del programa.");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opción inválida. Intente nuevamente.");
            }
        } while (opcion != 4);
    }
}

    
